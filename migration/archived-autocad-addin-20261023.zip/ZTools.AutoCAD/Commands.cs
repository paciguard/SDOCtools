using System;
using System.IO;
using System.Windows.Forms;
using Autodesk.AutoCAD.Runtime;
using AcadApp = Autodesk.AutoCAD.ApplicationServices.Core.Application;

[assembly: ExtensionApplication(typeof(ZTools.AutoCAD.Commands))]
[assembly: CommandClass(typeof(ZTools.AutoCAD.Commands))]

namespace ZTools.AutoCAD
{
    public sealed partial class Commands : IExtensionApplication
    {
        internal static string JobFolder;
        internal static PlotParameters PlotSettings = new PlotParameters();
        private static bool hasUi;
        public void Initialize()
        {
            hasUi = !System.Diagnostics.Process.GetCurrentProcess().ProcessName.Equals("accoreconsole",StringComparison.OrdinalIgnoreCase);
            if (hasUi) UiHost.Initialize();
            Write("凯乐提交文件工具已加载。输入 ZTOOLS 打开工具面板。");
        }
        public void Terminate() { if (hasUi) UiHost.Dispose(); }
        [CommandMethod("ZTOOLS", CommandFlags.Session)]
        public void ShowTools() { Run(() => UiHost.ShowPalette()); }
        [CommandMethod("ZTOOLSOPEN", CommandFlags.Session)]
        public void OpenJob() { Run(() => { SelectJob(true); if (hasUi) UiHost.RefreshJob(); }); }
        [CommandMethod("ZTOOLSSECLIST", CommandFlags.Session)]
        public void SectionInputs() { Run(() => { if (SelectJob()) ShowWorkbook("Sec-List"); }); }
        [CommandMethod("ZTOOLSPIDSET", CommandFlags.Session)]
        public void PidInputs() { Run(() => { if (SelectJob()) ShowWorkbook("PID"); }); }
        [CommandMethod("ZTOOLSDATA", CommandFlags.Session)]
        public void CalculatedData() { Run(() => { if (SelectJob()) ShowWorkbook("Sheet1"); }); }
        [CommandMethod("ZTOOLSPLOTSET", CommandFlags.Session)]
        public void PlotOptions()
        {
            Run(() => { using (var form = new PlotSettingsForm(PlotSettings.Copy()))
                if (Autodesk.AutoCAD.ApplicationServices.Application.ShowModalDialog(form) == DialogResult.OK)
                { PlotSettings = form.Parameters; Write("打印设置已更新，当前 AutoCAD 会话内有效。"); }
            });
        }
        [CommandMethod("ZTOOLSNEW", CommandFlags.Session)]
        public void NewJob() { Run(() => { using (var picker = new FolderBrowserDialog { Description = "请选择新建项目的保存位置" }) if (picker.ShowDialog() == DialogResult.OK) { JobFolder = ProjectPaths.CreateJob(picker.SelectedPath); Write("项目已创建：" + JobFolder); } }); }
        [CommandMethod("ZTOOLSINPUT", CommandFlags.Session)]
        public void EditInput() { Run(() => { if (SelectJob()) ShowWorkbook("input"); }); }
        [CommandMethod("ZTOOLSCALC", CommandFlags.Session)]
        public void Calculate() { Run(() => { if (SelectJob()) WithWorkbook((w,e) => e.Calculate()); }); }
        [CommandMethod("ZTOOLSUTILITY", CommandFlags.Session)]
        public void Utility() { Run(() => { if (SelectJob()) { WithWorkbook((w,e) => e.CalculateUtility()); ShowWorkbook("Utility"); } }); }
        [CommandMethod("ZTOOLSGA", CommandFlags.Session)]
        public void GA() { Generate("GA"); }
        [CommandMethod("ZTOOLSPID", CommandFlags.Session)]
        public void PID() { Generate("PID"); }
        [CommandMethod("ZTOOLSSEC", CommandFlags.Session)]
        public void SEC() { Generate("SEC"); }
        [CommandMethod("ZTOOLSALL", CommandFlags.Session)]
        public void All() { Generate("GA","PID","SEC"); }
        private void Generate(params string[] kinds) { Run(() => { if (SelectJob()) GenerateJob(kinds); }); }
        internal static void GenerateJob(params string[] kinds)
        {
            WithWorkbook((w,e) => { string output = new DrawingBatch(w,Write,PlotSettings).Generate(kinds); Write("图纸已生成，输出目录：" + output); });
        }
        internal static void WithWorkbook(Action<WorkbookSession, SubmissionEngine> action)
        {
            using (var workbook = new WorkbookSession(Path.Combine(JobFolder,"ZTools.xls"),false))
                action(workbook,new SubmissionEngine(workbook,Write));
        }
        internal static void ShowWorkbook(string sheet)
        {
            // Keep the private Excel session alive while the user edits, then save
            // and close before CAD reads it. No VBProject access or legacy macros.
            using (var workbook = new WorkbookSession(Path.Combine(JobFolder,"ZTools.xls"),true))
            {
                workbook.ShowInput(sheet);
                MessageBox.Show("请在 Excel 中编辑项目数据。\n编辑完成后，请返回此窗口并单击“确定”，保存并关闭项目工作簿。", Brand.ProductName + " — 数据输入", MessageBoxButtons.OK, MessageBoxIcon.Information);
                workbook.Save();
            }
        }
        internal static bool SelectJob(bool force = false)
        {
            if (!force && JobFolder != null && File.Exists(Path.Combine(JobFolder,"ZTools.xls"))) return true;
            using (var picker = new OpenFileDialog { Title = "请选择项目的 ZTools.xls 工作簿副本", Filter = "项目工作簿（ZTools.xls）|ZTools.xls", InitialDirectory = JobFolder ?? ProjectPaths.Root })
            {
                if (picker.ShowDialog() != DialogResult.OK) return false;
                string path = Path.GetFullPath(picker.FileName);
                if (string.Equals(path,ProjectPaths.SourceWorkbook,StringComparison.OrdinalIgnoreCase)) throw new InvalidOperationException("请选择项目副本，或单击“新建项目”创建副本。");
                JobFolder = Path.GetDirectoryName(path);
                return true;
            }
        }
        internal static void Run(Action action)
        {
            try { action(); }
            catch (System.Exception ex) { Write("错误：" + ex.Message); MessageBox.Show(ex.Message,Brand.ProductName,MessageBoxButtons.OK,MessageBoxIcon.Error); }
        }
        internal static void Write(string message)
        {
            AcadApp.DocumentManager.MdiActiveDocument?.Editor.WriteMessage("\n" + message);
            if (hasUi) UiHost.Log(message);
        }
    }
}
