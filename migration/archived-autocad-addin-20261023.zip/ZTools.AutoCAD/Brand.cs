using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using System.Windows.Media.Imaging;

namespace ZTools.AutoCAD
{
    internal static class Brand
    {
        internal const string ProductName = "凯乐提交文件工具";
        private const string LogoResource = "ZTools.AutoCAD.Assets.CFL-logo-white-background.jpg";

        private static Stream OpenLogo()
        {
            return typeof(Brand).Assembly.GetManifestResourceStream(LogoResource)
                ?? throw new InvalidOperationException("未找到内嵌的凯乐标志资源，请重新编译插件。");
        }

        internal static Bitmap CreateLogo()
        {
            using (var stream = OpenLogo())
            using (var image = Image.FromStream(stream)) return new Bitmap(image);
        }

        internal static BitmapImage RibbonLogo(int pixels)
        {
            using (var stream = OpenLogo())
            {
                var image = new BitmapImage();
                image.BeginInit();
                image.CacheOption = BitmapCacheOption.OnLoad;
                image.DecodePixelWidth = pixels;
                image.StreamSource = stream;
                image.EndInit();
                image.Freeze();
                return image;
            }
        }

        internal static Control Header(string subtitle, int height = 62)
        {
            var header = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 2,
                Height = height, MinimumSize = new Size(0,height), Margin = new Padding(0,0,0,8) };
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,62));
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
            header.RowStyles.Add(new RowStyle(SizeType.Percent,55));
            header.RowStyles.Add(new RowStyle(SizeType.Percent,45));
            var logo = new PictureBox { Image = CreateLogo(), SizeMode = PictureBoxSizeMode.Zoom,
                Dock = DockStyle.Fill, Margin = new Padding(0,0,8,0), AccessibleName = "凯乐 CFL 标志" };
            logo.Disposed += (s,e) => logo.Image?.Dispose();
            header.Controls.Add(logo,0,0); header.SetRowSpan(logo,2);
            header.Controls.Add(new Label { Text = ProductName, Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.BottomLeft, Font = new Font("Microsoft YaHei UI",11,FontStyle.Bold) },1,0);
            header.Controls.Add(new Label { Text = subtitle, Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleLeft, ForeColor = Color.FromArgb(45,96,135) },1,1);
            return header;
        }
    }
}
