using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Geometry;

namespace ZTools.AutoCAD
{
    // Compatibility surface for the ported drawing rules. All drawing operations
    // below use managed ObjectARX transactions; there is no AutoCAD COM/VBA bridge.
    internal sealed class CadDrawing
    {
        internal readonly Database Database;
        internal readonly Transaction Transaction;
        private readonly Dictionary<string, string> customProperties = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        public CadDrawing(Document document, Transaction transaction) : this(document.Database, transaction) { }
        internal CadDrawing(Database database, Transaction transaction)
        {
            Database = database;
            Transaction = transaction;
            ModelSpace = new CadModelSpace(this);
            var info = new DatabaseSummaryInfoBuilder(Database.SummaryInfo);
            foreach (System.Collections.DictionaryEntry entry in info.CustomPropertyTable)
                customProperties[Convert.ToString(entry.Key)] = Convert.ToString(entry.Value);
        }
        public CadDrawing Application => this;
        public CadDrawing ActiveDocument => this;
        public CadDrawing Layouts => this;
        public CadDrawing ActiveLayout => this;
        public CadDrawing Item(object name)
        {
            if (!string.Equals(Vb.Text(name), "Model", StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("这些图纸模板仅支持模型空间布局。");
            return this;
        }
        public CadModelSpace ModelSpace { get; }
        public CadModelSpace Block => ModelSpace;
        public CadLayers Layers => new CadLayers(this);
        public void SetCustomProperty(object name, object value)
        {
            string key = Vb.Text(name).Trim();
            if (key.Length != 0) customProperties[key] = Vb.Text(value);
        }
        public void CommitProperties()
        {
            var builder = new DatabaseSummaryInfoBuilder(Database.SummaryInfo);
            foreach (var pair in customProperties) builder.CustomPropertyTable[pair.Key] = pair.Value;
            Database.SummaryInfo = builder.ToDatabaseSummaryInfo();
        }
        internal BlockTableRecord ModelRecord => (BlockTableRecord)Transaction.GetObject(
            SymbolUtilityServices.GetBlockModelSpaceId(Database), OpenMode.ForWrite);
        internal static Point3d Point(object point)
        {
            var p = (double[])point;
            return new Point3d(p[0], p[1], p.Length > 2 ? p[2] : 0);
        }
    }

    internal sealed class CadModelSpace
    {
        private readonly CadDrawing drawing;
        public CadModelSpace(CadDrawing drawing) { this.drawing = drawing; }
        public int Count => drawing.ModelRecord.Cast<ObjectId>().Count();
        public CadEntity Item(object index)
        {
            var id = drawing.ModelRecord.Cast<ObjectId>().ElementAt(Vb.Int(index));
            return new CadEntity(drawing, (Entity)drawing.Transaction.GetObject(id, OpenMode.ForWrite));
        }
        public CadEntity AddMText(object point, object width, object content)
        {
            Point3d location = CadDrawing.Point(point);
            // PID.dwg contains two copies of stale job text at the four title-field
            // anchors. Replace text at the requested anchor instead of stacking it.
            foreach (ObjectId id in drawing.ModelRecord.Cast<ObjectId>().ToArray())
            {
                var existing = drawing.Transaction.GetObject(id,OpenMode.ForRead) as MText;
                if (existing != null && existing.Location.DistanceTo(location) < 0.000001)
                { existing.UpgradeOpen(); existing.Erase(); }
            }
            var text = new MText { Location = location, Width = Vb.Num(width), Contents = Vb.Text(content), TextHeight = 2.3 };
            text.SetDatabaseDefaults(drawing.Database);
            drawing.ModelRecord.AppendEntity(text);
            drawing.Transaction.AddNewlyCreatedDBObject(text, true);
            return new CadEntity(drawing, text);
        }
        public CadEntity InsertBlock(object point, object name, object sx, object sy, object sz, object angle)
        {
            string blockName = Vb.Text(name);
            if (string.IsNullOrWhiteSpace(blockName)) return null; // optional rule component
            if (blockName == "NONONONO") return null; // no auxiliary interfaces selected
            var table = (BlockTable)drawing.Transaction.GetObject(drawing.Database.BlockTableId, OpenMode.ForRead);
            if (!table.Has(blockName)) throw new InvalidOperationException("图纸模板缺少图块：" + blockName);
            var definition = (BlockTableRecord)drawing.Transaction.GetObject(table[blockName], OpenMode.ForRead);
            var reference = new BlockReference(CadDrawing.Point(point), definition.ObjectId)
            { ScaleFactors = new Scale3d(Vb.Num(sx), Vb.Num(sy), Vb.Num(sz)), Rotation = Vb.Num(angle) };
            reference.SetDatabaseDefaults(drawing.Database);
            drawing.ModelRecord.AppendEntity(reference);
            drawing.Transaction.AddNewlyCreatedDBObject(reference, true);
            foreach (ObjectId id in definition)
            {
                var attributeDefinition = drawing.Transaction.GetObject(id, OpenMode.ForRead) as AttributeDefinition;
                if (attributeDefinition == null || attributeDefinition.Constant) continue;
                var attribute = new AttributeReference();
                attribute.SetAttributeFromBlock(attributeDefinition, reference.BlockTransform);
                attribute.TextString = attributeDefinition.TextString;
                reference.AttributeCollection.AppendAttribute(attribute);
                drawing.Transaction.AddNewlyCreatedDBObject(attribute, true);
            }
            return new CadEntity(drawing, reference);
        }
    }

    internal sealed class CadEntity
    {
        private readonly CadDrawing drawing;
        private readonly Entity entity;
        internal CadEntity(CadDrawing drawing, Entity entity) { this.drawing = drawing; this.entity = entity; }
        public string ObjectName => entity is BlockReference ? "AcDbBlockReference" : entity.GetRXClass().Name;
        public string Name => ((BlockTableRecord)drawing.Transaction.GetObject(((BlockReference)entity).BlockTableRecord, OpenMode.ForRead)).Name;
        public double Height { get => ((MText)entity).TextHeight; set => ((MText)entity).TextHeight = value; }
        public double Width { get => ((MText)entity).Width; set => ((MText)entity).Width = value; }
        public void Update() { entity.RecordGraphicsModified(true); }
        public void ScaleEntity(object point, object factor) { entity.TransformBy(Matrix3d.Scaling(Vb.Num(factor), CadDrawing.Point(point))); }
        public CadAttribute[] GetAttributes()
        {
            var reference = entity as BlockReference;
            if (reference == null) return new CadAttribute[0];
            return reference.AttributeCollection.Cast<ObjectId>()
                .Select(id => new CadAttribute((AttributeReference)drawing.Transaction.GetObject(id, OpenMode.ForWrite))).ToArray();
        }
    }

    internal sealed class CadAttribute
    {
        private readonly AttributeReference attribute;
        internal CadAttribute(AttributeReference attribute) { this.attribute = attribute; }
        public string TagString => attribute.Tag;
        public string TextString { get => attribute.TextString; set => attribute.TextString = value ?? ""; }
    }

    internal sealed class CadLayers
    {
        private readonly CadDrawing drawing;
        internal CadLayers(CadDrawing drawing) { this.drawing = drawing; }
        public CadLayer Item(object name)
        {
            var table = (LayerTable)drawing.Transaction.GetObject(drawing.Database.LayerTableId, OpenMode.ForRead);
            string layerName = Vb.Text(name);
            if (!table.Has(layerName)) throw new InvalidOperationException("图纸模板缺少图层：" + layerName);
            return new CadLayer((LayerTableRecord)drawing.Transaction.GetObject(table[layerName], OpenMode.ForWrite));
        }
    }

    internal sealed class CadLayer
    {
        private readonly LayerTableRecord layer;
        internal CadLayer(LayerTableRecord layer) { this.layer = layer; }
        public bool LayerOn { get => !layer.IsOff; set => layer.IsOff = !value; }
    }
}
