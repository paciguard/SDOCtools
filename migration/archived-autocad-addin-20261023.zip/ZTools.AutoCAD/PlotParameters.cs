using System;

namespace ZTools.AutoCAD
{
    // Meaningful parameters from the three VBA PlotFunction procedures, plus an
    // explicit plot window for managed ObjectARX. Coordinates are drawing units.
    internal sealed class PlotParameters
    {
        public string PrinterName { get; set; } = "DWG To PDF.pc3";
        public string Styles { get; set; } = "acad.ctb";
        public string MediaName { get; set; } = "";
        public int Copies { get; set; } = 1;
        public bool AutoMedia { get; set; } = true;
        public bool AutoRotate { get; set; } = true;
        public bool AutoFrame { get; set; } = true;
        public double MinX { get; set; } = 0;
        public double MinY { get; set; } = 0;
        public double MaxX { get; set; } = 420;
        public double MaxY { get; set; } = 297;
        public PlotParameters Copy() => (PlotParameters)MemberwiseClone();
        public void Validate()
        {
            if (string.IsNullOrWhiteSpace(PrinterName)) throw new ArgumentException("请输入 AutoCAD PDF 绘图仪配置名称。");
            if (Copies < 1 || Copies > 99) throw new ArgumentOutOfRangeException(nameof(Copies),"打印份数必须为 1 至 99。");
            if (!AutoMedia && string.IsNullOrWhiteSpace(MediaName)) throw new ArgumentException("请输入标准纸张名称，或勾选自动选择 A3 纸张。");
            if (MaxX <= MinX || MaxY <= MinY) throw new ArgumentException("打印窗口的最大坐标必须大于对应的最小坐标。");
        }
    }
}
