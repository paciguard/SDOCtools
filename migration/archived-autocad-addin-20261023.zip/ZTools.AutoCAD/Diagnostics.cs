using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Runtime;
using AcadApp = Autodesk.AutoCAD.ApplicationServices.Core.Application;

namespace ZTools.AutoCAD
{
    public sealed partial class Commands
    {
        [CommandMethod("ZTOOLSPLOTTEST", CommandFlags.Session)]
        public void PlotCurrentSmoke()
        {
            string folder = Path.Combine(ProjectPaths.Root,"tests","plot-output");
            Directory.CreateDirectory(folder);
            string label = Path.GetFileNameWithoutExtension(AcadApp.DocumentManager.MdiActiveDocument.Name);
            string path = Path.Combine(folder,label + "-" + DateTime.Now.ToString("yyyyMMdd-HHmmss") + ".pdf");
            string result;
            try
            {
                var doc = AcadApp.DocumentManager.MdiActiveDocument;
                using (doc.LockDocument())
                {
                    PdfPlotter.Plot(doc,path);
                    if (label.StartsWith("PID",StringComparison.OrdinalIgnoreCase)) DrawingBatch.SavePidSheet(doc,Path.ChangeExtension(path,".dwg"));
                }
                if (!File.Exists(path) || new FileInfo(path).Length == 0) throw new IOException("PDF file is empty or missing.");
                result = "PLOT_SMOKE_OK " + path;
            }
            catch (System.Exception ex) { result = "PLOT_SMOKE_FAILED " + label + " " + ex; }
            File.AppendAllText(Path.Combine(folder,"plot-smoke.log"),result + Environment.NewLine,Encoding.UTF8);
            Write(result);
        }
        [CommandMethod("ZTOOLSTEMPLATES", CommandFlags.Session)]
        public void InspectTemplates()
        {
            var lines = new List<string>();
            foreach (string kind in new[] { "GA", "PID", "SEC" })
                using (var db = new Database(false,true))
                {
                    db.ReadDwgFile(Path.Combine(ProjectPaths.Templates,kind + ".dwg"),FileOpenMode.OpenForReadAndAllShare,true,"");
                    db.CloseInput(true);
                    using (var tx = db.TransactionManager.StartTransaction())
                    {
                        var definitions = (BlockTable)tx.GetObject(db.BlockTableId,OpenMode.ForRead);
                        lines.Add(kind + " DEFINITIONS " + string.Join(" | ",definitions.Cast<ObjectId>().Select(id => ((BlockTableRecord)tx.GetObject(id,OpenMode.ForRead)).Name)));
                        var model = (BlockTableRecord)tx.GetObject(SymbolUtilityServices.GetBlockModelSpaceId(db),OpenMode.ForRead);
                        foreach (ObjectId id in model)
                        {
                            var titleText = tx.GetObject(id,OpenMode.ForRead) as MText;
                            if (titleText != null && titleText.Location.X > 350 && titleText.Location.Y > 45 && titleText.Location.Y < 80)
                                lines.Add(kind + " TITLEMTEXT " + titleText.Location + " " + titleText.Text);
                            var block = tx.GetObject(id,OpenMode.ForRead) as BlockReference;
                            if (block == null || block.AttributeCollection.Count == 0) continue;
                            string name = ((BlockTableRecord)tx.GetObject(block.BlockTableRecord,OpenMode.ForRead)).Name;
                            string effective = block.IsDynamicBlock ? ((BlockTableRecord)tx.GetObject(block.DynamicBlockTableRecord,OpenMode.ForRead)).Name : name;
                            var tags = new List<string>();
                            foreach (ObjectId aid in block.AttributeCollection)
                            {
                                var attr = (AttributeReference)tx.GetObject(aid,OpenMode.ForRead);
                                tags.Add(attr.Tag + "=" + attr.TextString);
                            }
                            lines.Add(kind + " block=" + name + " effective=" + effective + " " + string.Join("; ",tags));
                        }
                    }
                }
            File.WriteAllLines(Path.Combine(ProjectPaths.Root,"tests","template-inventory.log"),lines,Encoding.UTF8);
            Write("Template inventory saved.");
        }
        // Noninteractive native integration check: use only new job/drawing copies.
        [CommandMethod("ZTOOLSSECSMOKE", CommandFlags.Session)]
        public void SectionSmoke()
        {
            string output = Path.Combine(ProjectPaths.Root,"tests","section-output",DateTime.Now.ToString("yyyyMMdd-HHmmss"));
            Directory.CreateDirectory(output);
            var log = new List<string>();
            try
            {
                string job = ProjectPaths.CreateJob(output);
                using (var workbook = new WorkbookSession(Path.Combine(job,"ZTools.xls"),false))
                {
                    var engine = new SubmissionEngine(workbook,s => log.Add(s));
                    engine.Calculate();
                    // Include the legacy LK6 nested-If failure, version 7/10,
                    // G supplements, and CZ diameter/shaft/frame boundaries.
                    string[][] cases = {
                        new[] { "ZE80-6200", "8th", "QWL", "" },
                        new[] { "ZE80-6200", "7th", "QFL", "" },
                        new[] { "ZE80-6200", "10th", "ZFL", "" },
                        new[] { "ZE80-2200", "10版", "QWL", "" },
                        new[] { "ZEG80-6200", "8th", "QWL", "" },
                        new[] { "ZEG80-2200", "7th", "QFL", "" },
                        new[] { "ZAG40-6200", "7th", "QWL", "" },
                        new[] { "ZA40-1200", "7th", "QSL", "" },
                        new[] { "ZF80-6200", "8th", "ZFL", "" },
                        new[] { "CZ50-200", "8th", "CZ轻轴", "LK30-225" },
                        new[] { "CZ50-200", "8th", "CZ重轴", "LK30-225" },
                        new[] { "CZ50-315", "8th", "CZ轻轴", "LK40-315" },
                        new[] { "CZ50-315", "8th", "CZ重轴", "LK40-315" },
                        new[] { "CZ50-315", "8th", "CZ重轴", "LK60-315" }
                    };
                    for (int k = 0; k < cases.Length; k++)
                    {
                        string[] item = cases[k];
                        var selection = SectionSelection.Resolve(item[0],item[1],item[2],item[3]);
                        dynamic sheet = workbook.Book.Worksheets["Sheet1"];
                        sheet.Range["C19"].Value2 = 40;
                        sheet.Range["C40"].Value2 = item[0];
                        sheet.Range["CA40"].Value2 = selection.TemplateName;
                        sheet.Range["CC40"].Value2 = selection.ListName;
                        sheet.Range["CB40"].Value2 = item[2];
                        sheet.Range["CD40"].Value2 = item[3];
                        sheet.Range["BY40"].Value2 = selection.IsG ? "Y" : "N";
                        sheet.Range["BZ40"].Value2 = selection.LargeBearing ? "Y" : "N";
                        workbook.Book.Worksheets["input"].Range["O21"].Value2 = "S-5";
                        workbook.Book.Worksheets["Sec-List"].Range["G10"].ClearContents();
                        string dataGap = null;
                        try { engine.PrepareSection(0); }
                        catch (InvalidOperationException ex) when (ex.Message.StartsWith("List-detail 中缺少零件：",StringComparison.Ordinal))
                        { dataGap = ex.Message; }
                        string template = workbook.Cell("Sheet1","CA40");
                        using (var database = new Database(false,true))
                        {
                            database.ReadDwgFile(Path.Combine(ProjectPaths.Templates,"SEC.dwg"),FileOpenMode.OpenForReadAndAllShare,true,"");
                            database.CloseInput(true);
                            using (var tx = database.TransactionManager.StartTransaction())
                            {
                                var blocks = (BlockTable)tx.GetObject(database.BlockTableId,OpenMode.ForRead);
                                if (dataGap != null)
                                {
                                    if (!blocks.Has(selection.TemplateName)) throw new InvalidOperationException("SEC base template missing: " + selection.TemplateName);
                                    log.Add("NAMES_PASS " + item[0] + "; CC=" + selection.ListName + "; base block=" + selection.TemplateName);
                                    log.Add("BLOCKED_DATA " + item[0] + ": " + dataGap + "; incomplete drawing intentionally not generated");
                                    continue;
                                }
                                if (!blocks.Has(template)) throw new InvalidOperationException("SEC template lacks Sheet1!CA40=" + template);
                                var model = (BlockTableRecord)tx.GetObject(SymbolUtilityServices.GetBlockModelSpaceId(database),OpenMode.ForRead);
                                Func<int> count = () => model.Cast<ObjectId>().Select(id => tx.GetObject(id,OpenMode.ForRead)).OfType<BlockReference>().Count(b => b.BlockTableRecord == blocks[template]);
                                int before = count();
                                engine.Drawing = new CadDrawing(database,tx);
                                engine.BuildSEC();
                                if (count() != before+1) throw new InvalidOperationException("Expected exactly one main SEC block: " + template);
                                tx.Commit();
                            }
                            database.SaveAs(Path.Combine(output,"SEC-case-" + (k+1) + ".dwg"),DwgVersion.Current);
                        }
                        log.Add("PASS " + item[0] + " / " + item[1] + " / " + item[2] + " -> CA=" + template + "; CC=" + selection.ListName + "; main block inserted once");
                    }
                }
                log.Add("SECTION_NAMES_SMOKE_OK");
                log.Add("DRAWINGS=" + log.Count(s => s.StartsWith("PASS ",StringComparison.Ordinal))
                    + "; DATA_GAPS=" + log.Count(s => s.StartsWith("BLOCKED_DATA ",StringComparison.Ordinal)));
            }
            catch (System.Exception ex) { log.Add("FAIL " + ex); }
            finally { File.WriteAllLines(Path.Combine(output,"section-smoke.log"),log,Encoding.UTF8); Write(string.Join("\n",log)); }
        }

        [CommandMethod("ZTOOLSSMOKE", CommandFlags.Session)]
        public void NativeSmoke()
        {
            string output = Path.Combine(ProjectPaths.Root,"tests","native-output",DateTime.Now.ToString("yyyyMMdd-HHmmss"));
            Directory.CreateDirectory(output);
            var log = new List<string>();
            try
            {
                string job = ProjectPaths.CreateJob(output);
                using (var workbook = new WorkbookSession(Path.Combine(job,"ZTools.xls"),false))
                {
                    var engine = new SubmissionEngine(workbook,s => { log.Add(s); Write(s); });
                    int count = engine.Calculate();
                    if (Environment.GetEnvironmentVariable("ZTOOLS_SMOKE_FIRST_ONLY") == "1") count = 1;
                    for (int k = 0; k < count; k++)
                    {
                        workbook.Book.Worksheets["Sheet1"].Range["C19"].Value2 = 40+k;
                        foreach (string kind in new[] { "GA", "PID", "SEC" })
                        {
                            if (kind == "SEC") engine.PrepareSection(k);
                            using (var database = new Database(false,true))
                            {
                                database.ReadDwgFile(Path.Combine(ProjectPaths.Templates,kind + ".dwg"),FileOpenMode.OpenForReadAndAllShare,true,"");
                                database.CloseInput(true);
                                using (var tx = database.TransactionManager.StartTransaction())
                                {
                                    var drawing = new CadDrawing(database,tx);
                                    engine.Drawing = drawing;
                                    if (kind == "GA") engine.BuildGA();
                                    else if (kind == "PID") engine.BuildPID();
                                    else engine.BuildSEC();
                                    drawing.CommitProperties();
                                    tx.Commit();
                                }
                                database.SaveAs(Path.Combine(output,kind + "-" + (k+1) + ".dwg"),DwgVersion.Current);
                                using (var tx = database.TransactionManager.StartTransaction())
                                {
                                    var model = (BlockTableRecord)tx.GetObject(SymbolUtilityServices.GetBlockModelSpaceId(database),OpenMode.ForRead);
                                    int attributes = 0;
                                    foreach (ObjectId id in model)
                                    {
                                        var block = tx.GetObject(id,OpenMode.ForRead) as BlockReference;
                                        if (block == null) continue;
                                        string blockName = ((BlockTableRecord)tx.GetObject(block.BlockTableRecord,OpenMode.ForRead)).Name;
                                        foreach (ObjectId aid in block.AttributeCollection)
                                        {
                                            var attribute = (AttributeReference)tx.GetObject(aid,OpenMode.ForRead);
                                            if (attribute.Tag.Equals("SHEBEIWEIHAO",StringComparison.OrdinalIgnoreCase))
                                            {
                                                if (attribute.TextString != workbook.Cell("Sheet1","B" + (40+k))) throw new InvalidOperationException("Equipment tag did not match in " + kind + " block " + blockName + ": actual '" + attribute.TextString + "', expected '" + workbook.Cell("Sheet1","B" + (40+k)) + "'");
                                                attributes++;
                                            }
                                        }
                                    }
                                    if (attributes == 0) throw new InvalidOperationException("No equipment-tag attribute was updated in " + kind);
                                    log.Add("PASS " + kind + " pump " + (k+1) + ": " + model.Cast<ObjectId>().Count() + " entities; equipment tag verified");
                                }
                            }
                        }
                    }
                }
                log.Add("NATIVE_SMOKE_OK");
            }
            catch (System.Exception ex) { log.Add("FAIL " + ex); }
            finally
            {
                File.WriteAllLines(Path.Combine(output,"native-smoke.log"),log,Encoding.UTF8);
                Write(string.Join("\n",log));
            }
        }
    }
}
