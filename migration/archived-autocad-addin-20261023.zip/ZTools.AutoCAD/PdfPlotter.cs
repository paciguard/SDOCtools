using System;
using System.Linq;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.PlottingServices;
using AcadApp = Autodesk.AutoCAD.ApplicationServices.Core.Application;

namespace ZTools.AutoCAD
{
    internal static class PdfPlotter
    {
        public static void Plot(Document document, string output, PlotParameters parameters = null)
        {
            parameters = parameters ?? new PlotParameters();
            parameters.Validate();
            if (PlotFactory.ProcessPlotState != ProcessPlotState.NotPlotting)
                throw new InvalidOperationException("AutoCAD 正在打印，请等待当前打印任务完成。");
            object background = AcadApp.GetSystemVariable("BACKGROUNDPLOT");
            try
            {
                AcadApp.SetSystemVariable("BACKGROUNDPLOT", 0);
                LayoutManager.Current.CurrentLayout = "Model";
                using (var tx = document.Database.TransactionManager.StartTransaction())
                using (var settings = new PlotSettings(true))
                using (var info = new PlotInfo())
                using (var validator = new PlotInfoValidator())
                {
                    var layout = (Layout)tx.GetObject(LayoutManager.Current.GetLayoutId("Model"), OpenMode.ForRead);
                    settings.CopyFrom(layout);
                    var psv = PlotSettingsValidator.Current;
                    psv.SetPlotConfigurationName(settings, parameters.PrinterName, null);
                    psv.RefreshLists(settings);
                    string media = parameters.AutoMedia ? psv.GetCanonicalMediaNameList(settings).Cast<string>()
                        .FirstOrDefault(n => n.IndexOf("ISO_A3", StringComparison.OrdinalIgnoreCase) >= 0 && n.Contains("420.00") && n.Contains("297.00")) : parameters.MediaName;
                    if (media == null) throw new InvalidOperationException("当前绘图仪未提供 ISO A3（420 × 297 毫米）纸张。");
                    psv.SetCanonicalMediaName(settings, media);
                    psv.SetPlotPaperUnits(settings, PlotPaperUnit.Millimeters);
                    bool paperLandscape = settings.PlotPaperSize.X >= settings.PlotPaperSize.Y;
                    bool windowLandscape = parameters.MaxX-parameters.MinX >= parameters.MaxY-parameters.MinY;
                    psv.SetPlotRotation(settings, parameters.AutoRotate && paperLandscape != windowLandscape ? PlotRotation.Degrees090 : PlotRotation.Degrees000);
                    psv.SetPlotWindowArea(settings, new Extents2d(new Point2d(parameters.MinX,parameters.MinY), new Point2d(parameters.MaxX,parameters.MaxY)));
                    psv.SetPlotType(settings, parameters.AutoFrame ? Autodesk.AutoCAD.DatabaseServices.PlotType.Window : Autodesk.AutoCAD.DatabaseServices.PlotType.Extents);
                    psv.SetUseStandardScale(settings, true);
                    psv.SetStdScaleType(settings, StdScaleType.ScaleToFit);
                    psv.SetPlotCentered(settings, true);
                    psv.SetCurrentStyleSheet(settings, string.IsNullOrWhiteSpace(parameters.Styles) ? "acad.ctb" : parameters.Styles);
                    settings.PlotPlotStyles = true;
                    settings.PrintLineweights = true;
                    info.Layout = layout.ObjectId;
                    info.OverrideSettings = settings;
                    validator.MediaMatchingPolicy = MatchingPolicy.MatchEnabled;
                    validator.Validate(info);
                    using (var engine = PlotFactory.CreatePublishEngine())
                    using (var page = new PlotPageInfo())
                    {
                        engine.BeginPlot(null, null);
                        engine.BeginDocument(info, document.Name, null, parameters.Copies, true, output);
                        engine.BeginPage(page, info, true, null);
                        engine.BeginGenerateGraphics(null);
                        engine.EndGenerateGraphics(null);
                        engine.EndPage(null);
                        engine.EndDocument(null);
                        engine.EndPlot(null);
                    }
                    tx.Commit();
                }
            }
            finally { AcadApp.SetSystemVariable("BACKGROUNDPLOT", background); }
        }
    }
}
