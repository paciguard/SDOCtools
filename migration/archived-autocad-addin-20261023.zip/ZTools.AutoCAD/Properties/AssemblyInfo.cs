using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("凯乐 AutoCAD 提交文件工具")]
[assembly: AssemblyDescription("基于原始 Excel 模板与数据库的 ObjectARX 提交图纸工具")]
[assembly: AssemblyCompany("凯乐 CFL")]
[assembly: AssemblyProduct("凯乐提交文件工具")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: ComVisible(false)]
