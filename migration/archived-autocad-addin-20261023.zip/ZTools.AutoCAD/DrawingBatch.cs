using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Geometry;
using AcadApp = Autodesk.AutoCAD.ApplicationServices.Core.Application;

namespace ZTools.AutoCAD
{
    internal sealed class DrawingBatch
    {
        private readonly WorkbookSession workbook;
        private readonly SubmissionEngine engine;
        private readonly Action<string> report;
        private readonly PlotParameters plotParameters;
        internal DrawingBatch(WorkbookSession workbook, Action<string> report, PlotParameters plotParameters = null)
        { this.workbook = workbook; this.report = report; engine = new SubmissionEngine(workbook,report); this.plotParameters = (plotParameters ?? new PlotParameters()).Copy(); }

        public string Generate(params string[] kinds)
        {
            int count = workbook.ValidateInput();
            for (int k = 0; k < count; k++)
                if (workbook.Cell("Sheet1","P" + (40+k)) == "") throw new InvalidOperationException("请先计算项目数据，再生成图纸。");
            foreach (string kind in kinds)
                if (!new[] { "GA", "PID", "SEC" }.Contains(kind)) throw new ArgumentException("未知图纸类型：" + kind);
            string run = Path.Combine(Path.GetDirectoryName(workbook.FilePath), "Output", DateTime.Now.ToString("yyyyMMdd-HHmmss") + "-" + Guid.NewGuid().ToString("N").Substring(0,6));
            Directory.CreateDirectory(run);
            var log = new List<string>();
            Document original = AcadApp.DocumentManager.MdiActiveDocument;
            object currentRow = workbook.Book.Worksheets["Sheet1"].Range["C19"].Value2;
            try
            {
                engine.PreparePid(count);
                foreach (string kind in kinds)
                {
                    string folder = Path.Combine(run,kind);
                    Directory.CreateDirectory(folder);
                    for (int k = 0; k < count; k++)
                    {
                        string address = (kind == "GA" ? "P" : kind == "PID" ? "Q" : "R") + (40+k);
                        string name = SafeFileName(workbook.Cell("Sheet1",address));
                        if (name.Length == 0) throw new InvalidOperationException("输出文件名为空：Sheet1!" + address);
                        string dwg = Path.Combine(folder,name + ".dwg");
                        string pdf = Path.Combine(folder,name + ".pdf");
                        if (File.Exists(dwg) || File.Exists(pdf)) throw new IOException("输入表第 " + (21+k) + " 行的输出文件名重复：" + name);
                        string kindName = kind == "GA" ? "总装外形图" : kind == "PID" ? "管路仪表图" : "剖面图及明细表";
                        report(kindName + "：第 " + (k+1) + "/" + count + " 台 — " + name);
                        workbook.Book.Worksheets["Sheet1"].Range["C19"].Value2 = 40+k;
                        if (kind == "SEC") engine.PrepareSection(k);
                        // A separate copy for every pump avoids carrying entities between items.
                        string working = Path.Combine(folder, ".working-" + k + ".dwg");
                        File.Copy(Path.Combine(ProjectPaths.Templates,kind + ".dwg"),working,false);
                        Document doc = null;
                        try
                        {
                            doc = AcadApp.DocumentManager.Open(working,false);
                            AcadApp.DocumentManager.MdiActiveDocument = doc;
                            using (doc.LockDocument())
                            {
                                using (var tx = doc.Database.TransactionManager.StartTransaction())
                                {
                                    var drawing = new CadDrawing(doc,tx);
                                    engine.Drawing = drawing;
                                    if (kind == "GA") engine.BuildGA();
                                    else if (kind == "PID") engine.BuildPID();
                                    else engine.BuildSEC();
                                    drawing.CommitProperties();
                                    tx.Commit();
                                }
                                doc.Editor.Regen();
                                PdfPlotter.Plot(doc,pdf,plotParameters);
                                if (kind == "PID") SavePidSheet(doc,dwg);
                                else doc.Database.SaveAs(dwg,DwgVersion.Current);
                            }
                            if (!File.Exists(pdf) || new FileInfo(pdf).Length == 0) throw new IOException("AutoCAD 未生成有效的 PDF 文件：" + pdf);
                            if (!File.Exists(dwg) || new FileInfo(dwg).Length == 0) throw new IOException("AutoCAD 未生成有效的 DWG 文件：" + dwg);
                            log.Add("成功\t" + kindName + "\t输入表第 " + (21+k) + " 行\t" + name);
                        }
                        catch (System.Exception ex)
                        {
                            log.Add("失败\t" + kindName + "\t输入表第 " + (21+k) + " 行\t" + ex);
                            throw new InvalidOperationException(kindName + "生成失败，输入表第 " + (21+k) + " 行：" + ex.Message + "\n运行日志：" + Path.Combine(run,"run.log"), ex);
                        }
                        finally
                        {
                            engine.Drawing = null;
                            if (doc != null) doc.CloseAndDiscard();
                            if (File.Exists(working)) File.Delete(working); // only this run's own temporary copy
                        }
                    }
                }
                log.Add("全部完成");
                return run;
            }
            finally
            {
                workbook.Book.Worksheets["Sheet1"].Range["C19"].Value2 = currentRow;
                workbook.Save();
                if (original != null) AcadApp.DocumentManager.MdiActiveDocument = original;
                File.WriteAllLines(Path.Combine(run,"run.log"),log,Encoding.UTF8);
            }
        }
        internal static string SafeFileName(string value)
        {
            var invalid = Path.GetInvalidFileNameChars();
            string name = new string(value.Where(c => !invalid.Contains(c) && !char.IsControl(c)).ToArray()).Trim().TrimEnd('.');
            return name;
        }
        internal static void SavePidSheet(Document doc, string target)
        {
            // The PID template contains a library of plan blocks outside the A3 sheet.
            // Match the VBA's window WBLOCK rather than exporting the entire library.
            var selected = doc.Editor.SelectWindow(new Point3d(0,0,0), new Point3d(420,297,0));
            if (selected.Status != PromptStatus.OK || selected.Value.Count == 0)
                throw new InvalidOperationException("A3 图纸窗口内未找到管路仪表图图元。");
            using (Database sheet = doc.Database.Wblock(new ObjectIdCollection(selected.Value.GetObjectIds()),Point3d.Origin))
                sheet.SaveAs(target,DwgVersion.Current);
        }
    }
}
