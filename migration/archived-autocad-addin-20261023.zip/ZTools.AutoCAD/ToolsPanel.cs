using System;
using System.Drawing;
using System.Windows.Forms;

namespace ZTools.AutoCAD
{
    internal sealed class ToolsPanel : UserControl
    {
        private readonly TextBox job = new TextBox { Dock = DockStyle.Top, ReadOnly = true, Multiline = true, Height = 54, BorderStyle = BorderStyle.FixedSingle };
        private readonly TextBox status = new TextBox { Dock = DockStyle.Fill, Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Vertical };
        private readonly FlowLayoutPanel groups = new FlowLayoutPanel { Dock = DockStyle.Top, AutoSize = true, FlowDirection = FlowDirection.TopDown, WrapContents = false };
        internal ToolsPanel()
        {
            Dock = DockStyle.Fill; Padding = new Padding(10); Font = new Font("Microsoft YaHei UI",9);
            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 4 };
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute,76));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute,64));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent,100));
            layout.Controls.Add(Brand.Header("项目输入 · 数据计算 · 图纸生成"));
            layout.Controls.Add(job);
            AddGroup("一、项目管理",new[] { "新建项目", "打开项目", "输入数据" },new[] { "ZTOOLSNEW", "ZTOOLSOPEN", "ZTOOLSINPUT" });
            AddGroup("二、数据计算",new[] { "计算数据", "公用工程用量表" },new[] { "ZTOOLSCALC", "ZTOOLSUTILITY" });
            AddGroup("三、提交图纸",new[] { "总装外形图", "管路仪表图", "剖面图及明细表", "生成全部图纸" },new[] { "ZTOOLSGA", "ZTOOLSPID", "ZTOOLSSEC", "ZTOOLSALL" });
            AddGroup("复核与设置",new[] { "剖面材料", "管仪图设置", "计算结果", "打印设置" },new[] { "ZTOOLSSECLIST", "ZTOOLSPIDSET", "ZTOOLSDATA", "ZTOOLSPLOTSET" });
            layout.Controls.Add(groups); layout.Controls.Add(status); Controls.Add(layout);
            Resize += (s,e) => ResizeGroups();
            ResizeGroups();
            RefreshJob();
        }
        private void AddGroup(string title, string[] labels, string[] commands)
        {
            int rows = (labels.Length+1)/2;
            var group = new GroupBox { Text = title, Width = 320, Height = 27 + rows*36, Padding = new Padding(8), Margin = new Padding(0,0,0,8) };
            var flow = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = rows };
            flow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,50));
            flow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,50));
            for (int r = 0; r < rows; r++) flow.RowStyles.Add(new RowStyle(SizeType.Percent,100f/rows));
            for (int i = 0; i < labels.Length; i++)
            {
                string command = commands[i];
                var button = new Button { Text = labels[i], Dock = DockStyle.Fill, Margin = new Padding(0,2,5,2) };
                button.Click += (s,e) => Commands.Run(() => UiHost.Enqueue(command));
                flow.Controls.Add(button,i%2,i/2);
            }
            group.Controls.Add(flow); groups.Controls.Add(group);
        }
        private void ResizeGroups()
        {
            foreach (Control group in groups.Controls) group.Width = Math.Max(265,ClientSize.Width-Padding.Horizontal-6);
        }
        internal void RefreshJob()
        {
            string value = Commands.JobFolder ?? "请先新建项目或打开已有项目。";
            if (job.Text != value) job.Text = value;
        }
        internal void Log(string text)
        {
            if (status.TextLength > 25000) status.Clear();
            status.AppendText(text + Environment.NewLine);
            RefreshJob();
        }
    }
}
