using System;
using System.Drawing;
using System.Windows.Forms;

namespace ZTools.AutoCAD
{
    internal sealed class PlotSettingsForm : Form
    {
        private readonly TextBox printer = new TextBox { Dock = DockStyle.Fill };
        private readonly TextBox styles = new TextBox { Dock = DockStyle.Fill };
        private readonly TextBox media = new TextBox { Dock = DockStyle.Fill };
        private readonly NumericUpDown copies = new NumericUpDown { Minimum = 1, Maximum = 99, Dock = DockStyle.Left, Width = 80 };
        private readonly CheckBox autoMedia = new CheckBox { Text = "自动选择 ISO A3 纸张", AutoSize = true };
        private readonly CheckBox rotate = new CheckBox { Text = "自动匹配打印窗口方向", AutoSize = true };
        private readonly CheckBox window = new CheckBox { Text = "使用模板窗口（取消后打印图形范围）", AutoSize = true };
        private readonly NumericUpDown[] coordinates = new NumericUpDown[4];
        internal PlotParameters Parameters { get; private set; }
        internal PlotSettingsForm(PlotParameters initial)
        {
            Text = Brand.ProductName + " — 打印设置"; StartPosition = FormStartPosition.CenterParent;
            ClientSize = new Size(570,520); FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false; MinimizeBox = false; Font = new Font("Microsoft YaHei UI",9);
            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(16), ColumnCount = 2, RowCount = 13 };
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,132));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute,72));
            var header = Brand.Header("打印参数设置");
            layout.Controls.Add(header,0,0); layout.SetColumnSpan(header,2);
            Action<string,Control,int> row = (label,control,index) => {
                layout.RowStyles.Add(new RowStyle(SizeType.Absolute,32));
                layout.Controls.Add(new Label { Text = label, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft },0,index+1);
                layout.Controls.Add(control,1,index+1);
            };
            row("绘图仪配置（PC3）",printer,0); row("打印样式（CTB）",styles,1); row("标准纸张名称",media,2); row("打印份数",copies,3);
            row("纸张选择",autoMedia,4); row("打印方向",rotate,5); row("打印区域",window,6);
            string[] labels = { "窗口最小 X 坐标", "窗口最小 Y 坐标", "窗口最大 X 坐标", "窗口最大 Y 坐标" };
            for (int i = 0; i < coordinates.Length; i++)
            {
                coordinates[i] = new NumericUpDown { Minimum = -100000, Maximum = 100000, DecimalPlaces = 2, Dock = DockStyle.Left, Width = 125 };
                row(labels[i],coordinates[i],7+i);
            }
            var buttons = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft };
            var ok = new Button { Text = "应用", AutoSize = true };
            ok.Click += (s,e) => {
                try
                {
                    var value = new PlotParameters { PrinterName = printer.Text.Trim(), Styles = styles.Text.Trim(), MediaName = media.Text.Trim(), Copies = (int)copies.Value,
                        AutoMedia = autoMedia.Checked, AutoRotate = rotate.Checked, AutoFrame = window.Checked,
                        MinX = (double)coordinates[0].Value, MinY = (double)coordinates[1].Value, MaxX = (double)coordinates[2].Value, MaxY = (double)coordinates[3].Value };
                    value.Validate(); Parameters = value; DialogResult = DialogResult.OK;
                }
                catch (Exception ex) { MessageBox.Show(this,ex.Message,Text,MessageBoxButtons.OK,MessageBoxIcon.Information); }
            };
            var cancel = new Button { Text = "取消", DialogResult = DialogResult.Cancel, AutoSize = true };
            var reset = new Button { Text = "恢复默认", AutoSize = true };
            reset.Click += (s,e) => Populate(new PlotParameters());
            buttons.Controls.Add(ok); buttons.Controls.Add(cancel); buttons.Controls.Add(reset);
            layout.RowStyles.Add(new RowStyle(SizeType.Percent,100)); layout.Controls.Add(buttons,0,12); layout.SetColumnSpan(buttons,2);
            Controls.Add(layout); AcceptButton = ok; CancelButton = cancel;
            autoMedia.CheckedChanged += (s,e) => media.Enabled = !autoMedia.Checked;
            Populate(initial);
        }
        private void Populate(PlotParameters p)
        {
            printer.Text = p.PrinterName; styles.Text = p.Styles; media.Text = p.MediaName; copies.Value = p.Copies;
            autoMedia.Checked = p.AutoMedia; rotate.Checked = p.AutoRotate; window.Checked = p.AutoFrame; media.Enabled = !p.AutoMedia;
            double[] values = { p.MinX,p.MinY,p.MaxX,p.MaxY };
            for (int i = 0; i < values.Length; i++) coordinates[i].Value = (decimal)values[i];
        }
    }
}
