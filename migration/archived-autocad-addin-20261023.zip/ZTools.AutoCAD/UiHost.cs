using System;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using Autodesk.AutoCAD.Windows;
using Autodesk.Windows;
using AcadApp = Autodesk.AutoCAD.ApplicationServices.Core.Application;

namespace ZTools.AutoCAD
{
    internal static class UiHost
    {
        private const string TabId = "ZTOOLS_SUBMISSION_TAB";
        private static PaletteSet palette;
        private static ToolsPanel panel;
        private static bool initialized;
        internal static void Initialize()
        {
            if (initialized) return;
            initialized = true;
            AcadApp.Idle += OnIdle;
        }
        private static void OnIdle(object sender, EventArgs args)
        {
            if (ComponentManager.Ribbon == null) return;
            AddRibbon();
            panel?.RefreshJob();
        }
        internal static void ShowPalette()
        {
            if (palette == null)
            {
                palette = new PaletteSet(Brand.ProductName,new Guid("2E254ADC-8456-439F-9269-F1CF57962AA5"))
                {
                    Style = PaletteSetStyles.ShowAutoHideButton | PaletteSetStyles.ShowCloseButton | PaletteSetStyles.ShowPropertiesMenu,
                    DockEnabled = DockSides.Left | DockSides.Right,
                    MinimumSize = new System.Drawing.Size(310,700),
                    Size = new System.Drawing.Size(370,790)
                };
                panel = new ToolsPanel();
                palette.Add("提交文件",panel);
                palette.Dock = DockSides.Left;
            }
            panel.RefreshJob();
            palette.Visible = true;
            if (ComponentManager.Ribbon != null) AddRibbon();
        }
        internal static void Log(string text) { panel?.Log(text); }
        internal static void RefreshJob() { panel?.RefreshJob(); }
        internal static void Enqueue(string command)
        {
            var document = AcadApp.DocumentManager.MdiActiveDocument;
            if (document == null) throw new InvalidOperationException("请先打开一张图纸，再使用凯乐工具。");
            document.SendStringToExecute(command + " ",true,false,true);
        }
        private static void AddRibbon()
        {
            RibbonControl ribbon = ComponentManager.Ribbon;
            if (ribbon.Tabs.Any(t => t.Id == TabId)) return;
            var tab = new RibbonTab { Id = TabId, Title = "凯乐工具" };
            var jobs = AddPanel(tab,"项目管理");
            AddButton(jobs,"工具\n面板","ZTOOLS","凯乐","打开可停靠的凯乐提交文件工具面板。");
            AddButton(jobs,"新建\n项目","ZTOOLSNEW","新建","复制原始输入模板并保留内置数据库，创建独立项目。");
            AddButton(jobs,"打开\n项目","ZTOOLSOPEN","打开","选择已有项目的工作簿副本。");
            AddButton(jobs,"输入\n数据","ZTOOLSINPUT","输入","打开项目的 Excel 输入表，填写设备和电机参数。");
            var calculations = AddPanel(tab,"数据计算");
            AddButton(calculations,"计算\n数据","ZTOOLSCALC","计算","计算外形尺寸、重量、管口载荷和图纸文件名。");
            AddButton(calculations,"公用工程\n用量表","ZTOOLSUTILITY","用量","计算冷却水及冲洗方案 62 的公用工程用量。");
            var drawings = AddPanel(tab,"提交图纸");
            AddButton(drawings,"总装\n外形图","ZTOOLSGA","总图","生成总装外形图的 DWG 和 PDF 文件。");
            AddButton(drawings,"管路\n仪表图","ZTOOLSPID","管仪","生成管路仪表图的 DWG 和 PDF 文件。");
            AddButton(drawings,"剖面图\n及明细表","ZTOOLSSEC","剖面","生成剖面图及零件材料明细表。");
            AddButton(drawings,"生成\n全部图纸","ZTOOLSALL","全部","在独立输出目录中生成总图、管仪图和剖面图。");
            var review = AddPanel(tab,"复核与设置");
            AddButton(review,"剖面\n材料","ZTOOLSSECLIST","材料","复核项目的剖面材料及指定材料覆盖值。");
            AddButton(review,"管仪图\n设置","ZTOOLSPIDSET","设置","出图前复核管路仪表图参数。");
            AddButton(review,"计算\n结果","ZTOOLSDATA","结果","查看及调整用于出图的计算结果。");
            AddButton(review,"打印\n设置","ZTOOLSPLOTSET","打印","设置绘图仪、打印样式、纸张、份数和打印窗口。");
            ribbon.Tabs.Add(tab);
        }
        private static RibbonPanelSource AddPanel(RibbonTab tab, string title)
        {
            var source = new RibbonPanelSource { Title = title };
            tab.Panels.Add(new RibbonPanel { Source = source });
            return source;
        }
        private static void AddButton(RibbonPanelSource source, string label, string command, string glyph, string hint)
        {
            source.Items.Add(new RibbonButton {
                Id = "ZTOOLS_BUTTON_" + command, Text = label, ShowText = true,
                ShowImage = true, Size = RibbonItemSize.Large,
                Orientation = System.Windows.Controls.Orientation.Vertical,
                Image = command == "ZTOOLS" ? Brand.RibbonLogo(16) : Icon(glyph,16),
                LargeImage = command == "ZTOOLS" ? Brand.RibbonLogo(32) : Icon(glyph,32), ToolTip = hint,
                CommandParameter = command, CommandHandler = new CommandHandler()
            });
        }
        private static ImageSource Icon(string glyph, double size)
        {
            var drawing = new DrawingGroup();
            using (var context = drawing.Open())
            {
                context.DrawRoundedRectangle(new SolidColorBrush(Color.FromRgb(32,102,153)),null,new Rect(1,1,size-2,size-2),3,3);
                var text = new FormattedText(glyph,CultureInfo.GetCultureInfo("zh-CN"),FlowDirection.LeftToRight,new Typeface("Microsoft YaHei UI"),glyph.Length > 2 ? size*.28 : size*.37,Brushes.White,1.0);
                context.DrawText(text,new Point((size-text.Width)/2,(size-text.Height)/2));
            }
            var image = new DrawingImage(drawing); image.Freeze(); return image;
        }
        internal static void Dispose()
        {
            if (!initialized) return;
            AcadApp.Idle -= OnIdle;
            if (ComponentManager.Ribbon != null)
            {
                var tab = ComponentManager.Ribbon.Tabs.FirstOrDefault(t => t.Id == TabId);
                if (tab != null) ComponentManager.Ribbon.Tabs.Remove(tab);
            }
            palette?.Dispose(); palette = null; panel = null; initialized = false;
        }
        private sealed class CommandHandler : ICommand
        {
            public bool CanExecute(object parameter) => AcadApp.DocumentManager.MdiActiveDocument != null;
            public void Execute(object parameter)
            {
                var button = parameter as RibbonButton;
                string command = button == null ? Convert.ToString(parameter) : Convert.ToString(button.CommandParameter);
                if (!string.IsNullOrWhiteSpace(command)) Commands.Run(() => Enqueue(command));
            }
            public event EventHandler CanExecuteChanged
            {
                add { CommandManager.RequerySuggested += value; }
                remove { CommandManager.RequerySuggested -= value; }
            }
        }
    }
}
