# 凯乐 AutoCAD 提交文件工具

C# AutoCAD 插件，使用托管 ObjectARX API，保留原始 Excel 输入模板与内置数据库。插件通过 `NETLOAD` 加载。

功能区、停靠面板、按钮、提示和打印设置均使用中文。您提供的 CFL／凯乐原始标志已内嵌至 DLL，用于功能区入口和窗口页眉，无需依赖外部图片路径。内部命令名称继续使用 `ZTOOLS` 系列，便于调用和兼容现有脚本。原始 `ZTools.xls` 及参考文件未作修改。

剖面图计算在 `Sheet1!CA40:CA69` 返回实际 SEC 主图块名称（包括适用的 `_K6`、`WO` 后缀），在 `CC40:CC69` 返回从 `List-all` **第 2 行查找到的实际材料清单名称**。搜索范围延伸到该行最后一个表头；缺少匹配或有重复名称时明确报错。材料清单和图块的命名格式不同，例如 `ZE8(LK6)_QWL` 对应图块 `ZE8_QWL_K6WO`（无护轴套）。SEC 出图直接读取 CA，不再重复拼接图块名。更新插件后，请先对已有项目执行一次“计算数据”。

## Build and load

The default target is **AutoCAD 2021, Windows x64, .NET Framework 4.8**, matching the installation on this machine. Microsoft Excel desktop is required to read, calculate and edit the original XLS workbook. Visual Studio with the .NET desktop workload and the .NET Framework 4.8 targeting pack is required to build. Neither VSTO nor the AutoCAD VBA Enabler is required at runtime.

1. Open `ZTools.sln` in Visual Studio, or run `powershell -ExecutionPolicy Bypass -File tools\build.ps1` from this folder.
2. In AutoCAD 2021 run `NETLOAD`, then select `ZTools.AutoCAD\bin\Release\ZTools.AutoCAD.dll`.
3. 使用 **凯乐工具** 功能区，或输入 `ZTOOLS` 打开停靠工具面板。如果功能区处于隐藏状态，可输入 `RIBBON` 显示。

功能区包含 **项目管理、数据计算、提交图纸、复核与设置** 四个面板，共 14 个按钮。停靠面板显示当前项目及操作日志。按钮通过注册的 AutoCAD 命令执行操作，工作空间切换时不会重复添加功能区。

**打印设置** 可调整绘图仪配置（PC3）、打印样式（CTB）、自动 A3 或指定纸张、份数、方向和打印窗口坐标。默认值沿用原 VBA 的 A3 PDF 出图流程，设置在当前 AutoCAD 会话内有效。PC3、CTB 和标准纸张的实际配置名称须与本机 AutoCAD 一致。

The build script also creates `dist\ZTools.bundle`, including all original reference files. To use AutoCAD's bundle discovery, copy the complete bundle into your per-user `%APPDATA%\Autodesk\ApplicationPlugins` folder. For a relocated DLL, keep the `Referrings` directory in an ancestor folder, or set `ZTOOLS_HOME` to this project directory. The reference Excel workbook is located by its full path, never by an unrelated active workbook.

The AutoCAD API assemblies are referenced with `Copy Local = false`. Do not distribute Autodesk's installed assemblies alongside this plug-in. For another AutoCAD release, rebuild against its matching managed ObjectARX SDK and update the bundle's release range. AutoCAD 2025 and later use a different .NET runtime and require a separate target.

## Workflow

1. **新建项目**：将 `Referrings\Ztools\ZTools.xls` 完整复制到独立项目目录，保留所有工作表、数据库、公式、验证规则和原 VBA。
2. **输入数据**：在独立 Excel 实例中打开项目副本，在 `input` 第 21–50 行连续填写泵数据。编辑完成后返回 AutoCAD 提示窗口，单击“确定”保存并关闭副本。该 Excel 实例禁用宏和工作簿事件。
3. **计算数据**：使用迁移后的 C# 规则和 Excel 内置数据库生成 `Sheet1` 计算结果及管仪方案数据。缺少参数或数据库匹配时给出中文提示，计算失败会恢复原计算区域。
4. 使用 **剖面材料、管仪图设置、计算结果** 复核或调整项目副本。出图使用当前计算结果；修改输入后应重新计算，重新计算会覆盖计算值。
5. 选择 **总装外形图、管路仪表图、剖面图及明细表、生成全部图纸**。每次运行在独立 `Output\<时间戳-编号>` 目录生成 DWG、PDF 和 `run.log`，保留以前生成的文件。

The utility list uses `UtilityData` inside the workbook. The original VBA's note still applies: external flush flow, Plan 62 entries and headers can need order-specific manual adjustment.

## Commands

| Command | Action |
| --- | --- |
| `ZTOOLS` | Open the job window |
| `ZTOOLSNEW` | Create a job copy |
| `ZTOOLSOPEN` | Select an existing job copy |
| `ZTOOLSINPUT` | Edit job inputs in Excel |
| `ZTOOLSCALC` | Calculate dimensions, weights, nozzle loads and drawing names |
| `ZTOOLSUTILITY` | Calculate and open the utility list |
| `ZTOOLSGA` | Generate general arrangement DWG/PDF files |
| `ZTOOLSPID` | Generate PID DWG/PDF files |
| `ZTOOLSSEC` | Generate section and bill-of-materials DWG/PDF files |
| `ZTOOLSALL` | Generate all three document types |
| `ZTOOLSSECLIST` | Review section material overrides |
| `ZTOOLSPIDSET` | Review PID settings |
| `ZTOOLSDATA` | Review calculated drawing data |
| `ZTOOLSPLOTSET` | Configure PDF plotting parameters |

Commands retain the selected job for the AutoCAD session. Use **Open job** to switch jobs. If no job is selected, a workbook picker opens. Only job copies are editable through the add-in. The supplied pump database supports CZ, ZA, ZE, ZE7 and ZF. Custom display prefixes remain supported by the original input fields. Other pump database families must be supplied before they can be calculated.

## Source and migration

- `Referrings`: original XLS, three DVB files, three DWG templates, backup drawing and images; retained without modification.
- `migration/legacy`: extracted VBA source for traceability.
- `migration/source-manifest.json`: original file sizes and SHA-256 hashes.
- `migration/workbook-schema.json`: workbook sheet names, dimensions and sample structure.
- `ZTools.AutoCAD/Generated`: C# ports of the workbook calculations and GA/PID/SEC drawing rules, with line markers for the normalized rules used by the converter.
- `ZTools.AutoCAD/CadDrawing.cs`: managed ObjectARX transaction, block, attribute, layer and text operations.
- `ZTools.AutoCAD/SubmissionEngine.cs`: workbook coordination, PID parsing, utility calculations and section-material preparation.
- `ZTools.AutoCAD/PdfPlotter.cs`: managed AutoCAD PDF plotting.
- `tools/port_vba.py`: targeted development-time converter for these source files. Python extraction dependencies are development tools only; the add-in uses C# and the installed applications at runtime.

The supplied workbook is not opened for writing during migration. The supplied VBA is retained as reference; production commands never call `RunMacro`, `LoadDVB`, `Application.Run` or the VBProject API. Excel's password `123` is used when opening job copies; VBA project locking does not prevent read-only source extraction.

See `migration/README.md` for migration decisions and verification results.
See `migration/methods-and-parameters.md` for VBA-to-C# method, parameter, cell-contract and AutoCAD UI API mappings.

## API references

- [Autodesk: managed .NET compatibility](https://help.autodesk.com/cloudhelp/2026/ENU/AutoCAD-Customization/files/GUID-A6C680F2-DE2E-418A-A182-E4884073338A.htm)
- [Autodesk: plot from model space](https://help.autodesk.com/cloudhelp/2015/ENU/AutoCAD-NET/files/GUID-6E0B1F7B-7B0E-4E3E-B1FD-018E0A3673BE.htm)
