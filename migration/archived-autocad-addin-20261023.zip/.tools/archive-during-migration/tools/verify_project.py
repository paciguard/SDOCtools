"""Check production command/UI wiring and the packaged reference files."""
import hashlib
import argparse
import json
import re
import xml.etree.ElementTree as ET
from pathlib import Path

root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
current = 'migration/source-manifest-20261023.json'
parser.add_argument('--manifest', default=current if (root/current).is_file() else 'migration/source-manifest.json', help='Reference snapshot relative to the project root')
args = parser.parse_args()
print('Reference snapshot:', args.manifest)
commands = set(re.findall(r'CommandMethod\("(ZTOOLS\w*)"', (root/'ZTools.AutoCAD/Commands.cs').read_text(encoding='utf-8')))
ribbon = set(re.findall(r'AddButton\([^,]+,\s*"(?:[^"\\]|\\.)*",\s*"(ZTOOLS\w*)"', (root/'ZTools.AutoCAD/UiHost.cs').read_text(encoding='utf-8')))
palette = set(re.findall(r'"(ZTOOLS\w*)"',(root/'ZTools.AutoCAD/ToolsPanel.cs').read_text(encoding='utf-8')))
manifest = ET.parse(root/'deploy/PackageContents.xml')
registered = {node.attrib['Global'] for node in manifest.findall('.//Command')}
assert len(commands) == 14 and commands == ribbon == registered, (commands,ribbon,registered)
assert palette == commands-{'ZTOOLS'}, palette
print('PASS: 14 registered commands match all ribbon buttons; 13 palette buttons are wired.')
bundle = root/'dist/ZTools.bundle'
entries = json.loads((root/args.manifest).read_text(encoding='utf-8'))
for entry in entries:
    path = bundle/entry['path']
    assert hashlib.sha256(path.read_bytes()).hexdigest() == entry['sha256'], path
packaged = list((bundle/'Referrings').rglob('*'))
assert sum(p.is_file() for p in packaged) == len(entries), 'Unexpected extra or missing packaged references'
print(f'PASS: all {len(entries)} packaged reference files match the selected source snapshot.')
