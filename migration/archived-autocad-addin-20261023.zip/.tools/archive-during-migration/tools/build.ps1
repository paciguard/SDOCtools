param(
    [string]$AutoCADDir = 'C:\Program Files\Autodesk\AutoCAD 2021',
    [ValidateSet('Debug','Release')][string]$Configuration = 'Release'
)
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
if (-not (Test-Path -LiteralPath $vswhere)) { throw 'Install Visual Studio or Build Tools with the .NET desktop workload and .NET Framework 4.8 targeting pack.' }
$msbuild = & $vswhere -latest -products * -requires Microsoft.Component.MSBuild -find 'MSBuild\**\Bin\MSBuild.exe' | Select-Object -First 1
if (-not $msbuild) { throw 'MSBuild was not found.' }
& $msbuild (Join-Path $projectRoot 'ZTools.sln') /t:Build "/p:Configuration=$Configuration" /p:Platform=x64 "/p:AutoCADDir=$AutoCADDir" /p:UseSharedCompilation=false /m:1 /nr:false /v:minimal /nologo
if ($LASTEXITCODE -ne 0) { throw 'Build failed.' }
$bundle = Join-Path $projectRoot 'dist\ZTools.bundle'
$windows = Join-Path $bundle 'Contents\Windows'
New-Item -ItemType Directory -Force -Path $windows | Out-Null
Copy-Item -LiteralPath (Join-Path $projectRoot "ZTools.AutoCAD\bin\$Configuration\ZTools.AutoCAD.dll") -Destination $windows -Force
Copy-Item -LiteralPath (Join-Path $projectRoot "ZTools.AutoCAD\bin\$Configuration\ZTools.AutoCAD.pdb") -Destination $windows -Force
Copy-Item -LiteralPath (Join-Path $projectRoot 'deploy\PackageContents.xml') -Destination $bundle -Force
Copy-Item -LiteralPath (Join-Path $projectRoot 'Referrings') -Destination $bundle -Recurse -Force
$source = Join-Path $projectRoot 'Referrings\Ztools\ZTools.xls'
$copy = Join-Path $bundle 'Referrings\Ztools\ZTools.xls'
# Verification remains read-only when the original workbook is open in Excel.
function Get-SharedFileHash([string]$Path) {
    $stream = [System.IO.File]::Open($Path,[System.IO.FileMode]::Open,[System.IO.FileAccess]::Read,[System.IO.FileShare]::ReadWrite)
    $hasher = [System.Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($hasher.ComputeHash($stream)).Replace('-','') }
    finally { $stream.Dispose(); $hasher.Dispose() }
}
if ((Get-SharedFileHash $source) -ne (Get-SharedFileHash $copy)) { throw 'Packaged workbook hash mismatch.' }
Write-Host "Built AutoCAD plug-in bundle: $bundle"
