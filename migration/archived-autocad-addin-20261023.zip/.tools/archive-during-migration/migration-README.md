# Migration record

## Scope

The final application is a C# AutoCAD 2021 plug-in using the managed ObjectARX API. The initial Excel VSTO direction was superseded by the requested AutoCAD host. The repository contains one application project, `ZTools.AutoCAD`, and a separate workbook integration-test executable.

Read-only extraction recovered 38 modules from `ZTools.xls` and two modules from each of `GA.dvb`, `PID.dvb` and `SEC.dvb`. Empty document modules, fully commented older implementations, scratch tests and the unused shell declaration remain in the extracted reference source. They are not executed by the new application.

| Original source | C# implementation |
| --- | --- |
| Excel Module1 `tranfer_data` | `Generated/WorkbookCalculations.cs`, coordinated by `SubmissionEngine.Calculate` |
| Excel Module2 `GAcreat` | `DrawingBatch.Generate("GA")` |
| Excel Module4 `SecCreate` | `SubmissionEngine.PrepareSection`, `DrawingBatch.Generate("SEC")` |
| Excel Module5/6 PID parsing and generation | `SubmissionEngine.PreparePid`, `DrawingBatch.Generate("PID")` |
| Excel Module7 `Utility` | `SubmissionEngine.CalculateUtility` |
| Excel navigation and UserForms | Native AutoCAD ribbon panels and dockable tools panel |
| GA Module1 drawing construction | `Generated/GADrawing.cs`, `CadDrawing` |
| PID Module1 drawing construction | `Generated/PIDDrawing.cs`, `CadDrawing` |
| SEC Module1 drawing construction | `Generated/SECDrawing.cs`, `CadDrawing` |
| Three plot routines | `PdfPlotter` using AutoCAD's managed plotting services |

The former login/admin forms, progress forms, window-caption modifications, workbook-open/close events and application-quit behavior are replaced by native AutoCAD commands and UI. The legacy password dialogs are not an authentication mechanism in the new add-in. The original VBA remains embedded in job copies but is disabled in the private Excel instance. No runtime VBA execution or VBA project modification is required.

## Preservation

`source-manifest.json` records the initial SHA-256 hash and size of every supplied reference file. `tools/verify_sources.py` verifies these originals. Job creation and deployment copy the XLS file directly, preserving all 20 worksheets, embedded databases, original formulas, validation, formatting and VBA storage. Only job copies are edited. Opening uses the supplied password `123`.

The extracted source is UTF-8. Some original SEC comments and existing workbook labels already contain encoding damage; no replacement database or invented labels were introduced into the original workbook.

## Deliberate corrections

- The original drawing code reads `ObjectName` into a string and then accesses `.Name` on it. It also expects title blocks named `AAA` and BOM blocks named `BBB`. The actual templates split attributes across `hetongxinxi`, `title`, `zhongliang`, `qudongcanshu`, interface blocks and `List`. The migrated attribute maps match tags across the actual block references.
- The current section VBA labels columns 79 and 82 as CE and CF, although CE is 83 and CF is 84. The new code uses the correct cells, matching the drawing reader.
- Section-list lookup searches all supplied list headers rather than rejecting valid headers after the first 40. The rendered parts list remains limited to the template's 40 attribute rows.
- SEC name selection now returns the actual DWG main block in `Sheet1!CA` and searches the actual `List-all` row 2 for the material-list name returned to `CC`. Searches include appended columns, preserve the matched cell's spelling, and reject missing or ambiguous headers. The legacy LK6 nested-If error and duplicate CZ insertion are corrected; version 7 G assemblies use their own supplement. Material overrides update the optional WO suffix before drawing generation. The migrated calculation addresses `Sheet1` by name even after sheets are reordered. See `methods-and-parameters.md` for the complete cell contract.
- Numeric and textual part identifiers are compared consistently: database value `400.1` matches text identifier `400.10`. The list's display spelling is retained.
- Section database lookups fail on missing detail or material records rather than copying a row after the lookup range.
- The original calculation loops over the full pump database and repeatedly recalculates the same values. The migrated calculation finds the matching pump/baseplate record once, while retaining the original dimension, mass, standard and nozzle-load rules. Automatic Excel recalculation is temporarily suspended and restored after an explicit full calculation.
- Per-pump ZE7 state is reset between rows. Custom display-prefix filenames retain the complete pump model instead of using only the replacement prefix.
- PID component and variant handling avoids invalid empty insertions. Plans 52/53A/53B/53C, 72 and C/S/A use the variant blocks chosen by the supplied rules rather than also attempting absent raw block names. The template supplies no standalone Plan 61 block; its original label-only handling remains. Other missing required blocks stop generation with the block name in the error.
- A new template copy is used for every drawing. PID DWG export retains the original A3 window WBLOCK behavior so the plan library outside the sheet is excluded.
- The supplied PID template contains two copies of stale customer/equipment title text. Text at the four exact title-field anchors is replaced before adding the current job's values. Formatted Excel dates are used in title attributes instead of numeric OLE date serials. Landscape media is plotted without a second 90-degree rotation.
- Output runs get unique directories; existing output folders do not have to be deleted. Drawing errors are reported and logged rather than suppressed by `On Error Resume Next`.
- The add-in never quits the user's AutoCAD session. It owns and closes only its private Excel instance and its temporary drawing documents.

## Validation

`tests/WorkbookSmoke.csproj` is a standalone .NET Framework 4.8 executable. It works on a fresh XLS copy with macros disabled and checks the six supplied pump rows, 13 dimensions per pump against the source database, total mass, section lists, combined PID plans, utility lookup, failed-lookup rollback, input-gap rejection and source-workbook preservation.

`ZTOOLSTEMPLATES` inventories actual template block definitions and attributes without modifying the originals. `ZTOOLSSMOKE` runs the C# builders inside AutoCAD Core Console against copied workbooks and side databases, saves sample DWGs and verifies the equipment-tag attributes. `ZTOOLSPLOTTEST` checks managed PDF plotting of a generated drawing. These diagnostic commands are explicitly invoked development checks, not automatically run when the production plug-in is loaded.

Verification results and any remaining host-only checks are recorded in `verification.txt` after the final build.

The initial `source-manifest.json` is retained as the 2026-10-21 historical
baseline. The references now include five additional EXB files and a newer XLS;
`source-manifest-20261023.json` records the current 16-file reference set.
`verify_sources.py` and `verify_project.py` default to this current snapshot and
print its path; use `--manifest migration/source-manifest.json` to audit the old
baseline explicitly. The original
SEC DWG was restored from an exact hash-matching backup after the first Core
Console host was rewritten on exit. Further checks use only `tests/section-host.dwg`
as the console input. Never pass an original template as the console's `/i`
argument; AutoCAD Core Console can save its input drawing when it exits.

`ZTOOLSSECSMOKE` checks SEC names against real template blocks and list headers,
then builds representative SEC variants. It reports missing List-detail records
as `BLOCKED_DATA` and does not generate an incomplete drawing for those cases.
